<?php

namespace App\Http\Controllers;

use app\Models\Company;
use Illuminate\Http\Request;

class CompanyController extends Controller
{
    public function index()
    {
        $companies = Company::latest()->paginate(10);
      return view ('companies.index')->with('companies', $companies);
    }
 
    
    public function create()
    {
        return view('companies.create');
    }
 
  
    public function store(Request $request)
    {
        $request->validate([
            'Name' => 'required',
         
        ]);
    }
 
    
    public function show($id)
    {
        $companies = Company::find($id);
        return view('companies$companies.show')->with('companies$companies', $companies);
    }
 
    
    public function edit($id)
    {
        $companies = Company::find($id);
        return view('companies$companies.edit')->with('companies$companies', $companies);
    }
 
  
    public function update(Request $request, $id)
    {
        $companies = Company::find($id);
        $input = $request->all();
        $companies->update($input);
        return redirect('companies$companies')->with('flash_message', 'Company Updated!');  
    }
 
  
    public function destroy($id)
    {
        Company::destroy($id);
        return redirect('companies$companies')->with('flash_message', 'Company deleted!');  
    }
}
